import fs from 'fs';
import configLoader from './modules/configLoader.mjs';
import { exportBaserowDatabases } from './modules/baserowProcessor.mjs';
import { convertJsonToDocs } from './modules/jsonToDocsProcessor.mjs';

(async () => {
  try {
    // Load all configs
    const configs = await configLoader.loadConfigs();

    for (const { filename, baserow, jsonToDocs } of configs) {
      console.log(`\n*** Processing Config: ${filename} ***`);
      console.log('');

      // Process Baserow data
      if (baserow?.doProcess) {
        console.log('Processing Baserow data...');
        const baserowToJSON = JSON.parse(fs.readFileSync(baserow.databasesFile, 'utf-8'));
        await exportBaserowDatabases(baserow, baserowToJSON);
        console.log('✅ Baserow export completed!\n');
      } else {
        console.log('⏭ Baserow processing skipped.\n');
      }

      // Process JSON to Docs
      if (jsonToDocs?.doProcess) {
        console.log('Processing JSON to Documents...');
        const templatesToDocs = JSON.parse(fs.readFileSync(jsonToDocs.docsTemplatesFile, 'utf-8'));
        await convertJsonToDocs(jsonToDocs, templatesToDocs);
        console.log('✅ JSON to Documents processing completed!\n');
      } else {
        console.log('⏭ JSON to Docs processing skipped.\n');
      }

      console.log(`\n*** Finished Processing Config: ${filename} ***\n`);
    }

    console.log('\n🎉 All configurations processed successfully!');
  } catch (error) {
    console.error('❌ Error during processing:', error.message);
    process.exit(1);
  }
})();
