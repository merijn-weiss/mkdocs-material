import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';

export async function loadConfigs() {
  const rootFolder = process.cwd();
  let configFolder = '/config/';
  const configFolderIndex = process.argv.indexOf('--configFolder');

  if (configFolderIndex > -1) configFolder = process.argv[configFolderIndex + 1];

  const configFullPathInput = path.join(rootFolder, configFolder);
  process.env.NODE_CONFIG_DIR = configFullPathInput;

  // Initialize dotenv
  dotenv.config({ path: `${rootFolder}/.env` });

  // Get all valid process JSON files (`process.*.json` and `process-*.json`)
  let availableConfigFiles = fs.readdirSync(configFullPathInput)
    .filter(file => (file.startsWith('process.') || file.startsWith('process-')) && file.endsWith('.json'));

  // If no process-*.json files are found, use process.json as the fallback
  if (availableConfigFiles.length === 0 && fs.existsSync(path.join(configFullPathInput, 'process.json'))) {
    console.log('⚠️ No specific process-*.json found. Using process.json as default.');
    availableConfigFiles = ['process.json'];
  }

  // Use explicit order from processOrder.cnf (if exists)
  const orderFilePath = path.join(configFullPathInput, 'processOrder.cnf');
  let orderedFiles = availableConfigFiles;

  if (fs.existsSync(orderFilePath)) {
    console.log(`🔄 Using process order from: ${orderFilePath}`);
    const order = fs.readFileSync(orderFilePath, 'utf-8')
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('#') && !line.startsWith('//'));

    // Filter only valid config files
    orderedFiles = order.filter(file => {
      if (availableConfigFiles.includes(file)) {
        return true;
      } else {
        console.warn(`⚠️ Skipping file from processOrder.cnf (not found in /config/): ${file}`);
        return false;
      }
    });

    // Add any missing wildcard files that weren't in processOrder.cnf
    const missingFiles = availableConfigFiles.filter(file => !orderedFiles.includes(file));
    if (missingFiles.length > 0) {
      console.log('\n⚠️ The following files were not listed in processOrder.cnf but will be added at the end:');
      missingFiles.forEach(file => console.log(`   - ➕ ${file}`));
      orderedFiles = [...orderedFiles, ...missingFiles]; // Append missing files to execution order
    }
  }

  // Debug: Print the actual execution order
  console.log('\n📂 Available config files:', availableConfigFiles);
  console.log('📜 Execution order:', orderedFiles);

  // Process each config file separately
  const configs = [];

  for (const file of orderedFiles) {
    const filePath = path.join(configFullPathInput, file);
    const rawConfig = JSON.parse(fs.readFileSync(filePath, 'utf8'));

    console.log(`📄 Loading config: ${file}`);

    // Define a constant for asset suffix
    const ASSETS_SUFFIX = '__assets/';

    // Process Baserow config
    const baserowConfig = rawConfig.baserowToJSON
      ? (() => {
        const jsonOutputFullPath = path.join(rootFolder, rawConfig.baserowToJSON?.json?.pathOutput ?? '');
        const assetsOutputFullPath = rawConfig.baserowToJSON?.assets?.pathOutput
          ? path.join(rootFolder, rawConfig.baserowToJSON.assets.pathOutput)
          : `${jsonOutputFullPath}${ASSETS_SUFFIX}`;

        return {
          doProcess: rawConfig.baserowToJSON?.doProcess ?? false,
          doDropOutputDirectory: rawConfig.baserowToJSON?.doDropOutputDirectory ?? false,
          databasesFile: path.join(configFullPathInput, rawConfig.baserowToJSON?.databases ?? ''),
          apiURL: rawConfig.baserowToJSON?.baserow?.apiURL ?? '',
          jsonOutputFullPath,
          assetsOutputFullPath,
        };
      })()
      : undefined;

    // Process jsonToDocs config
    const jsonToDocsConfig = rawConfig.jsonToDocs
      ? (() => {
        const docsOutputFullPath = path.join(rootFolder, rawConfig.jsonToDocs?.docs?.pathOutput ?? '');
        const jsonInputFullPath = path.join(rootFolder, rawConfig.jsonToDocs?.json?.pathInput ?? '');
        const assetsInputFullPath = rawConfig.jsonToDocs?.assets?.pathInput
          ? path.join(rootFolder, rawConfig.jsonToDocs.assets.pathInput)
          : `${jsonInputFullPath}${ASSETS_SUFFIX}`;
        const assetsOutputFullPath = rawConfig.jsonToDocs?.assets?.pathOutput
          ? path.join(rootFolder, rawConfig.jsonToDocs.assets.pathOutput)
          : `${docsOutputFullPath}${ASSETS_SUFFIX}`;

        return {
          doProcess: rawConfig.jsonToDocs?.doProcess ?? false,
          doDropOutputDirectory: rawConfig.jsonToDocs?.doDropOutputDirectory ?? false,
          docsTemplatesFile: path.join(configFullPathInput, rawConfig.jsonToDocs?.docTemplates ?? ''),
          docsOutputFullPath,
          jsonInputFullPath,
          templatesInputFullPath: path.join(rootFolder, rawConfig.jsonToDocs?.templates?.pathInput ?? ''),
          assetsInputFullPath,
          assetsOutputFullPath,
        };
      })()
      : undefined;

    // Add config entry to the list
    configs.push({
      filename: file,
      baserow: baserowConfig,
      jsonToDocs: jsonToDocsConfig,
    });
  }

  console.log('\n✅ All configurations loaded successfully!');
  return configs; // Return array of config objects
}

export default { loadConfigs };