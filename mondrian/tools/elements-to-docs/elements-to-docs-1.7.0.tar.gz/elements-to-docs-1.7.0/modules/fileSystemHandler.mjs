import fs from 'fs';
import path from 'path';

export function ensureDirectoryExists(filePath) {
  const dirPath = path.dirname(filePath);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

export function writeFile(filePath, content, type = 'doc') {
  ensureDirectoryExists(filePath);
  try {
    if (type === 'json')
    {
      let jsonContent;
      if(typeof content === 'string')
      {
        // Replace newline & tab characters with the specified replacement tag
        const replacementTag = ' ';
        let fixedContent = content.normalize("NFC");
        fixedContent = fixedContent.replace(/(\r\n|\n|\t|\r|\u2028|\u2029)/g, replacementTag);
        
        // If the replacement tag is a space, collapse multiple spaces into a single space
        if (replacementTag === ' ') {
          fixedContent = fixedContent.replace(/ {2,}/g, ' ');
        }

        fixedContent = fixedContent.replace(/\\(?!["\\/bfnrtu])/g, '\\\\'); // Fix bad escapes
        
        jsonContent = JSON.parse(fixedContent);
      }
      else
      {
        jsonContent = content;
      }
      
      fs.writeFileSync(filePath, JSON.stringify(jsonContent, null, 2), 'utf-8');
    }
    else
    {
      fs.writeFileSync(filePath, content, 'utf-8');
    }

    console.log(`File written: ${filePath}`);
  } catch (error) {
    console.error(`Failed to write file ${filePath}: ${error.message}`);
    console.error(content);
  }
}

// Remove Directory & Files
export function removeDirectory(dirPath) {
  try { var files = fs.readdirSync(dirPath); }
  catch (e) { return; }
  if (files.length > 0)
    for (var i = 0; i < files.length; i++) {
      var filePath = dirPath + '/' + files[i];
      if (fs.statSync(filePath).isFile())
        fs.unlinkSync(filePath);
      else
        removeDirectory(filePath);
    }
  fs.rmdirSync(dirPath);
}

export function copyFileIfNotExists(src, dest) {
  if (!fs.existsSync(src)) {
    console.error(`Source file does not exist: ${src}`);
    return;
  }
  
  if (!fs.existsSync(dest)) {
    // Ensure that the destination directory exists
    ensureDirectoryExists(dest);
    try {
      fs.copyFileSync(src, dest);
      //console.log(`Copied file from ${src} to ${dest}`);
    } catch (error) {
      console.error(`Error copying file from ${src} to ${dest}:`, error);
    }
  } else {
    //console.log(`File already exists at ${dest}`);
  }
};
