import fs from 'fs';
import path from 'path';
import Handlebars from 'handlebars';
import { applyFiltersAndSort } from './jsonArrayHandler.mjs';
import { removeDirectory, writeFile, copyFileIfNotExists } from './fileSystemHandler.mjs';

export async function convertJsonToDocs(jsonToDocsConfig, templatesToDocs) {

  if (jsonToDocsConfig.doDropOutputDirectory) {
    console.log(`Drop ${jsonToDocsConfig.docsOutputFullPath}\n`);
    removeDirectory(jsonToDocsConfig.docsOutputFullPath);
  }

  const jsonFullPathInput = jsonToDocsConfig.jsonInputFullPath;
  const templateFullPathInput = jsonToDocsConfig.templatesInputFullPath;
  const docFullPathOutput = jsonToDocsConfig.docsOutputFullPath;

  const templateContext = {
    docFullPathOutput: docFullPathOutput,
    assetFullpathInput: jsonToDocsConfig.assetsInputFullPath,
    assetFullpathOutput: jsonToDocsConfig.assetsOutputFullPath
  };

  console.log('Input Folder (JSON):', jsonFullPathInput);
  console.log('Input Folder (Templates):', templateFullPathInput);
  console.log('Output Folder (Docs):', docFullPathOutput);
  console.log('');

  // Process each template configuration
  for (const templateConfig of templatesToDocs.templates) {
    const {json, templates, docsFolder, filterBy, orderBy, generateSeparateFiles, fileName, fileType = 'doc', extraAttributes } = templateConfig;
    
    // Load JSON data
    const jsonDataPath = path.join(jsonFullPathInput, json);
    const jsonData = JSON.parse(fs.readFileSync(jsonDataPath, 'utf-8'));

    let filteredData = applyFiltersAndSort(jsonData, filterBy, orderBy)

    if (!Array.isArray(filteredData) || filteredData.length === 0) {
      console.log(`No data matched filter criteria for templates: ${templates.join(', ')}`);
      continue;
    }

    const currentDocOutputFolder = path.join(docFullPathOutput, docsFolder || '');
    templateContext.currentDocOutputFolder = currentDocOutputFolder;
    console.log('templateContext: ', templateContext);
    
    // Generate documents
    if (generateSeparateFiles) {
      for (const filteredDataItem of filteredData) {
        const dataItem = { extraAttributes: extraAttributes, ...filteredDataItem };
        const fileContent = jsonToTemplate(templateContext, templateFullPathInput, templates, dataItem, extraAttributes);

        let docFilePath = generateFileName(currentDocOutputFolder, fileName, dataItem);
        writeFile(docFilePath, fileContent, fileType);
      }
    } else {
      const dataItems = { extraAttributes: extraAttributes, items: filteredData };
      const fileContent = jsonToTemplate(templateContext, templateFullPathInput, templates, dataItems, extraAttributes);

      let docFilePath = generateFileName(currentDocOutputFolder, fileName, dataItems);
      writeFile(docFilePath, fileContent, fileType);
    }
  }
}

// Apply JSON to templates and generate content
function jsonToTemplate(templateContext, templateFullPathInput, templates, item, extraAttributes) {
  let combinedContent = '';

  // Extract items from item.items if it's an array; otherwise, default to an empty array.
  const itemsArray = Array.isArray(item.items) ? item.items : [];

  // Build the context object with separate keys for items and templateContext
  const finalContext = {
    templateContext: templateContext,
    extraAttributes: extraAttributes,
    item: item,
    items: itemsArray
  };

  templates.forEach((templateFile) => {
    const templateFilePath = path.join(templateFullPathInput, templateFile);

    if (!fs.existsSync(templateFilePath)) {
      console.error(`Template file ${templateFile} not found.`);
      return;
    }

    const template = fs.readFileSync(templateFilePath, 'utf-8');
    const compiledTemplate = Handlebars.compile(template);

    combinedContent += compiledTemplate(finalContext) + '\n';
  });

  return combinedContent;
}

// Generate dynamic file names
function generateFileName(outputDir, template, data) {
  const getNestedValue = (obj, path) => {
    return path.split('.').reduce((acc, key) => acc && acc[key] !== undefined ? acc[key] : 'unknown', obj);
  };
  
  const dynamicFileName = template.replace(/{{(.*?)}}/g, (_, key) => getNestedValue(data, key));  

  return path.join(outputDir, dynamicFileName);
}

// *** Handlebar Helpers *** //
Handlebars.registerHelper('isequal', function (value, value2) {
  return value === value2;
});

Handlebars.registerHelper('parsedotnotation', function (fieldName) {
  let context = this;
  return context[fieldName];
});

Handlebars.registerHelper('isDefined', function (value, options) {
  if (typeof value !== 'undefined') {
    return options.fn(this); // Block content for "defined"
  } else {
    return options.inverse(this); // Block content for "undefined"
  }
});

Handlebars.registerHelper("localizeAsset", function (assetPath, options) {
  // Get templateContext from the root data
  const templateContext = options.data.root.templateContext;
  const fromPath = templateContext.currentDocOutputFolder;
  const toPath = templateContext.assetFullpathOutput;
  //console.log('localizeAsset', templateContext);

  // Compute the relative path from currentDocOutputFolder to assetFullpathOutput
  const relativePath = path.relative(fromPath, toPath);

  // Build the full source and destination paths for the asset file
  const assetSource = path.join(templateContext.assetFullpathInput, assetPath);
  const assetDest = path.join(templateContext.assetFullpathOutput, assetPath);

  // Copy the asset file if it doesn't exist at the destination
  copyFileIfNotExists(assetSource, assetDest);

  // Return the relative path combined with the asset filename.
  // This ensures that the asset can be referenced relatively from the output folder.
  let finalPath = path.join(relativePath, assetPath);
  // Convert backslashes (on Windows) to forward slashes for URL consistency
  finalPath = finalPath.split(path.sep).join('/');

  return finalPath;
});

Handlebars.registerHelper('replaceNewlines', function(text, options) {
  // Set the default replacement tag to '<br>'
  var replacementTag = options.hash.tag || ' ';
  
  // Escape the input text to prevent XSS attacks
  var escapedText = Handlebars.escapeExpression(text);
  
  // Replace newline characters with the specified replacement tag
  var result = escapedText.replace(/(\r\n|\n|\r)/g, replacementTag);
  
  // If the replacement tag is a space, collapse multiple spaces into a single space
  if (replacementTag === ' ') {
    result = result.replace(/ {2,}/g, ' ');
  }
  
  // Return the result as a SafeString to prevent Handlebars from escaping the HTML
  return new Handlebars.SafeString(result);
});

// Utility to resolve nested keys safely
function getNestedValue(obj, path) {
  return path.split('.').reduce((acc, key) => {
    if (acc && typeof acc === 'object' && key in acc) {
      return acc[key];
    }
    return undefined;
  }, obj);
}

// Group by one or more nested keys
const groupByMultiple = (arr, keys) => {
  if (!keys || keys.length === 0) return { "All Items": arr };

  return arr.reduce((result, item) => {
    let currentLevel = result;

    keys.forEach((keyPath, index) => {
      const value = getNestedValue(item, keyPath) ?? "Ungrouped";

      if (!currentLevel[value]) {
        currentLevel[value] = index === keys.length - 1 ? [] : {};
      }

      if (index === keys.length - 1) {
        currentLevel[value].push(item);
      } else {
        currentLevel = currentLevel[value];
      }
    });

    return result;
  }, {});
};

// Register the improved Handlebars helpers
Handlebars.registerHelper("groupBy", function (items, keyString, options) {
  const keys = keyString ? keyString.split(",") : [];
  const grouped = groupByMultiple(items, keys);

  // ✅ Render directly if single-level grouping
  return Object.entries(grouped)
    .map(([group, values]) => {
      // If the grouped value is an array → render items directly
      if (Array.isArray(values)) {
        return options.fn({ group, items: values });
      }

      // If it's an object (multi-level group), render recursively
      return options.fn({ group, subgroups: values });
    })
    .join("");
});

Handlebars.registerHelper("eachGroup", function (subgroups, options) {
  if (!subgroups) return "";

  return Object.entries(subgroups)
    .map(([group, subItems]) => {
      const isArray = Array.isArray(subItems);
      return options.fn({
        group,
        items: isArray ? subItems : undefined,
        subgroups: isArray ? undefined : subItems
      });
    })
    .join("");
});

Handlebars.registerHelper('replace', function(str, search, replacement) {
  if (typeof str !== 'string') {
    return str;
  }

  return str.replace(search, replacement);
});

Handlebars.registerHelper('fieldValue', function (fieldName, options) {
  const value = this[fieldName];

  if (value === undefined || value === null) {
    return '';
  }

  if (Array.isArray(value)) {
    return value
      .map(item => {
        if (item === undefined || item === null) return '';
        if (typeof item === 'object' && 'value' in item) return item.value;
        return item;
      })
      .filter(v => v !== '')
      .join(',');
  }

  if (typeof value === 'object' && 'value' in value) {
    return value.value;
  }

  return value;
});