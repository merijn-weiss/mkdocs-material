import fs from 'fs';
import path from 'path';
import { writeFile, ensureDirectoryExists, removeDirectory } from './fileSystemHandler.mjs';
import { applyFiltersAndSort } from './jsonArrayHandler.mjs';
import fetch from 'node-fetch';

export async function exportBaserowDatabases(baserowConfig, configBaserowToJSON) {
  
  if(baserowConfig.doDropOutputDirectory)
  {
    console.log(`Drop ${baserowConfig.jsonOutputFullPath}\n`);
    removeDirectory(baserowConfig.jsonOutputFullPath);
  }

  for (const database of configBaserowToJSON.databases) {
    const apiToken = getApiToken(database.apiKey || 'BR_API_KEY');
    
    const uniqueTableKey = database.uniqueTableKey;    
    const databasesUniqueTableKeyViolation = database.uniqueTableKeyViolation || "WARN";
    let uniqueTableKeySet = new Set();

    for (const tableObj of database.tables) {
      const { table, jsonFile, filterBy, orderBy, uniqueTableKeyViolation } = tableObj;
      const jsonFilePath = constructJsonFilePath(baserowConfig.jsonOutputFullPath, jsonFile);

      let assetPathOutput;
      if(tableObj.assetPath)
        assetPathOutput = constructAssetPathOutput(jsonFilePath, tableObj.assetPath);
      else
        assetPathOutput = baserowConfig.assetsOutputFullPath;
      
      const finalUniqueTableKeyViolation = (uniqueTableKeyViolation) || databasesUniqueTableKeyViolation;

      const allElements = await fetchTableData(table, apiToken, assetPathOutput, baserowConfig.apiURL, uniqueTableKey, finalUniqueTableKeyViolation, uniqueTableKeySet);

      writeFile(jsonFilePath, applyFiltersAndSort(allElements, filterBy, orderBy), 'json');
    }
  }
}

function getApiToken(apiKey) {
  return process.env[apiKey];
}

function constructJsonFilePath(outputDir, jsonFile) {
  return path.join(outputDir, jsonFile);
}

function constructAssetPathOutput(jsonFilePath, assetPath) {
  return path.join(path.dirname(jsonFilePath), assetPath);
}

async function fetchTableData(tableID, apiToken, assetPathOutput, apiURL, uniqueTableKey, uniqueTableKeyViolation, uniqueTableKeySet) {
  const allElements = [];
  let dataURL = `${apiURL}/database/rows/table/${tableID}/?user_field_names=true`;

  do {
    console.log(`Fetching data from: ${dataURL}`);
    const { results, nextURL } = await fetchTablePage(dataURL, apiToken);
    let addElement = true;

    for (const item of results) {
      if(uniqueTableKey)
      {
        let uniqueTableKeyValue = item[uniqueTableKey];
        addElement = (typeof uniqueTableKeyValue !== 'undefined' && uniqueTableKeyValue !== '' && !uniqueTableKeySet.has(uniqueTableKeyValue));
        if(addElement)
        {
          uniqueTableKeySet.add(uniqueTableKeyValue)
        }
        else
        {
          if(uniqueTableKeyViolation === 'DROP')
          {
            console.log(`${uniqueTableKeyViolation}: uniqueTableKey ${uniqueTableKey} has none-uniqueTableKeyValue ${uniqueTableKeyValue}.`);
          }
          else if(uniqueTableKeyViolation === 'WARN')
          {
            console.log(`${uniqueTableKeyViolation}: uniqueTableKey ${uniqueTableKey} has none-uniqueTableKeyValue ${uniqueTableKeyValue}.`);
            addElement = true;
          }
          else
          {
            addElement = true;
          }
        }
      }

      if(addElement)
        allElements.push(await transformItem(item, assetPathOutput));
    }

    dataURL = nextURL ? nextURL.replace('http://', 'https://') : null;
  } while (dataURL);

  return allElements;
}

async function fetchTablePage(url, apiToken) {
  const response = await fetch(url, {
    method: 'GET',
    headers: { Authorization: `Token ${apiToken}` },
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch data: ${response.statusText}`);
  }

  const data = await response.json();
  return { results: data.results, nextURL: data.next };
}

async function transformItem(input, imagePath) {
  const output = {};

  for (const [key, value] of Object.entries(input)) {
    if (Array.isArray(value)) {
      output[key] = await transformArray(value, imagePath);
    } else if (typeof value === 'object' && value !== null) {
      output[key] = value.value || value;
    } else {
      output[key] = value === null ? '' : value;
    }
  }

  return output;
}

async function transformArray(value, imagePath) {
  const promises = value.map(async (item) => {
    if (typeof item === 'object' && item !== null) {
      if ('url' in item) {
        const imgFile = `${imagePath}${item.name}`;
        await downloadImage(item.url, imgFile);
        return item;
      }
      return item.value || item;
    }
    return item;
  });

  return Promise.all(promises);
}

async function downloadImage(url, filePath) {
  ensureDirectoryExists(filePath);

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch image: ${url}`);
    }

    const buffer = Buffer.from(await response.arrayBuffer());
    fs.writeFileSync(filePath, buffer);
    console.log(`Image downloaded: ${filePath}`);
  } catch (error) {
    console.error(`Error downloading image: ${error.message}`);
  }
}