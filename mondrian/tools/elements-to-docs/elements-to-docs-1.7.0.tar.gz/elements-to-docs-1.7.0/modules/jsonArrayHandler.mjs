Array.prototype.sortByConfig = function (orderByConfig) {
  // Helper to resolve nested paths like "metadata.labels.type"
  const getNestedValue = (obj, path) => {
    if (!obj || !path) return undefined;
    return path.split('.').reduce((acc, key) => {
      if (acc && Object.prototype.hasOwnProperty.call(acc, key)) {
        return acc[key];
      }
      return undefined;
    }, obj);
  };

  return this.sort((a, b) => {
    for (const { attribute, direction } of orderByConfig) {
      const dir = direction === 'desc' ? -1 : 1;

      const valueA = getNestedValue(a, attribute);
      const valueB = getNestedValue(b, attribute);

      // Handle null/undefined
      if (valueA == null && valueB == null) continue;
      if (valueA == null) return dir;
      if (valueB == null) return -dir;

      // Compare numbers
      if (typeof valueA === 'number' && typeof valueB === 'number') {
        if (valueA !== valueB) return dir * (valueA - valueB);
      }

      // Compare strings
      const strA = String(valueA);
      const strB = String(valueB);
      const comparison = strA.localeCompare(strB, undefined, { sensitivity: 'base' });
      if (comparison !== 0) return dir * comparison;
    }

    return 0;
  });
};

Array.prototype.filterByConfig = function (filterConfig) {
  const { logicalOperator = 'AND', conditionGroups = [] } = filterConfig || {};

  return this.filter(item => {
    const groupResults = conditionGroups.map(({ logicalOperator = 'AND', conditions = [] }) => {
      const conditionResults = conditions.map(({ attribute, condition, value }) => {
        const itemValue = item[attribute];
        const conditionValue = Array.isArray(value) ? value : [value]; // Ensure value is always an array

        switch (condition) {
          case 'equals':
            if (Array.isArray(itemValue)) {
              return logicalOperator === 'AND'
                ? conditionValue.every(val => itemValue.includes(val)) // AND: All values must be in itemValue
                : conditionValue.some(val => itemValue.includes(val)); // OR: Any value must be in itemValue
            }
            return logicalOperator === 'AND'
              ? conditionValue.every(val => val === itemValue) // AND: All values must match itemValue
              : conditionValue.some(val => val === itemValue); // OR: Any value must match itemValue

          case 'notEquals':
            if (Array.isArray(itemValue)) {
              return logicalOperator === 'AND'
                ? conditionValue.every(val => !itemValue.includes(val)) // AND: All values must not be in itemValue
                : conditionValue.some(val => !itemValue.includes(val)); // OR: Any value must not be in itemValue
            }
            return logicalOperator === 'AND'
              ? conditionValue.every(val => val !== itemValue) // AND: All values must not match itemValue
              : conditionValue.some(val => val !== itemValue); // OR: Any value must not match itemValue

          case 'contains':
            if (Array.isArray(itemValue)) {
              return logicalOperator === 'AND'
                ? conditionValue.every(val =>
                    itemValue.some(
                      itemVal =>
                        typeof itemVal === 'string' &&
                        typeof val === 'string' &&
                        itemVal.toLowerCase().includes(val.toLowerCase())
                    )
                  ) // AND: All values must be contained in itemValue
                : conditionValue.some(val =>
                    itemValue.some(
                      itemVal =>
                        typeof itemVal === 'string' &&
                        typeof val === 'string' &&
                        itemVal.toLowerCase().includes(val.toLowerCase())
                    )
                  ); // OR: Any value must be contained in itemValue
            }
            return typeof itemValue === 'string' &&
              conditionValue.some(val => itemValue.toLowerCase().includes(val.toLowerCase()));

          case 'notContains':
            if (Array.isArray(itemValue)) {
              return logicalOperator === 'AND'
                ? conditionValue.every(val =>
                    itemValue.every(
                      itemVal =>
                        typeof itemVal === 'string' &&
                        typeof val === 'string' &&
                        !itemVal.toLowerCase().includes(val.toLowerCase())
                    )
                  ) // AND: All values must not be contained in itemValue
                : conditionValue.some(val =>
                    itemValue.every(
                      itemVal =>
                        typeof itemVal === 'string' &&
                        typeof val === 'string' &&
                        !itemVal.toLowerCase().includes(val.toLowerCase())
                    )
                  ); // OR: Any value must not be contained in itemValue
            }
            return typeof itemValue === 'string' &&
              conditionValue.every(val => !itemValue.toLowerCase().includes(val.toLowerCase()));

          case 'greaterThan':
            return itemValue > value;

          case 'lessThan':
            return itemValue < value;

          case 'empty':
            return !itemValue || (Array.isArray(itemValue) && itemValue.length === 0);

          case 'notEmpty':
            return itemValue && (!Array.isArray(itemValue) || itemValue.length > 0);

          default:
            return false;
        }
      });

      return logicalOperator === 'AND' ? conditionResults.every(Boolean) : conditionResults.some(Boolean);
    });

    return logicalOperator === 'AND' ? groupResults.every(Boolean) : groupResults.some(Boolean);
  });
};

export function applyFiltersAndSort(elements, filterBy, orderBy) {
  let filtered = filterBy ? elements.filterByConfig(filterBy) : elements;
  return orderBy ? filtered.sortByConfig(orderBy) : filtered;
}