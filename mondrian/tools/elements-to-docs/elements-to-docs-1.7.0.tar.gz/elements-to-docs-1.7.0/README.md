# elements-to-docs

Elements-to-Docs has two functions:

1. Export of Baserow Tables to JSON
2. Conversion of JSON to documents, such as Markdown, using Handlebar Templates

## process.json

The `process.json` file controls what function or functions must be processed. The `process.json` file contains two sections:

- `baserowToJSON`: Configuration for exporting data from Baserow to JSON files.
- `jsonToDocs`: Configuration for converting JSON data into documents using templates.

You only include the functions you want to process.

The `process.json` will be picked up from the ```config``` folder relative to the execution of the program when run without parameters. If you want to specify an alternative folder run ```node main.js --configFolder {path to configFolder}```.

If you want to run multiple processes you can include multiple `process*.json` or `process-*.json` files. The process files are executed in a sequential, lexicographical order. This can be overwritten by inluding `processOrder.cnf` file. E.g if you want to first process `process.jsonToDocs.servicenow.json` and then `process.jsonToDocs.baserow.json` include a `processOrder.cnf` file with the following content in the config folder:

***processOrder.cnf***

```text
# Define the order of processing
process.jsonToDocs.servicenow.json
process.jsonToDocs.baserow.json
```

### baserowToJSON

This section handles the configuration for processing Baserow databases into JSON format.

| Key                      | Type    | Description                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `doProcess`              | boolean | Whether to process the Baserow data export.                                                      |
| `doDropOutputDirectory`  | boolean | Whether the output directory will be removed before processing begins.                      |
| `databases`              | string  | File name containing the Baserow Datables to export.                                       |
| `baserow.apiURL`         | string  | API for accessing Baserow.                                |
| `json.pathOutput`        | string  | Directory path where the exported JSON files will be saved.                                   |
| `assets.pathOutput`      | string  | (Optional) Directory path where the Files will be saved. If not specified files are saved under `{json.pathOutput}/__assets`.                                    |

### jsonToDocs

This section handles the configuration for processing JSON object arrays into documents using Handlebar Templates for transformation.

| Key                      | Type    | Description                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `doProcess`              | boolean | Whether to process the JSON to Doc conversion.                                                      |
| `doDropOutputDirectory`  | boolean | Whether the output directory will be removed before processing begins.                      |
| `docTemplates`           | string  | File name containing the JSON files to convert.                                              |
| `json.pathInput`    | string  | Directory path where the JSON files are stored that are used for conversion.                                   |
| `templates.pathInput`    | string  | Directory path where the templates are stored that are used for conversion.                                   |
| `docs.pathOutput`        | string  | Directory path where the converted doc files will be saved.                                   |
| `assets.pathInput`      | string  | (Optional) Directory path where the input assets are stored that are used for conversion. If not specified the files are assumed under `{json.pathInput}/__assets`.                                  |
| `assets.pathOutput`      | string  | (Optional) Directory path where the input assets are copied to when the `localizeAsset` Handlebars Helper is used. If not specified the files are stored under `{docs.pathOutput}/__assets`.                                   |

### Example

This example will execute both functions. Hereby **baserowToJSON** is always the first function to execute after which **jsonToDocs** is executed, both depending on the **doProcess** attribute. So in this example the results that are stored by **baserowToJSON** in **json.pathOutput** will be used by **jsonToDocs** as **json.pathInput**.

``` json
{
    "baserowToJSON": {
        "doProcess": true,
        "doDropOutputDirectory": true,
        "databases": "baserow.to.json.json",
        "baserow": {
            "apiURL": "https://elements.mondrian-it.io/api"
        },
        "json": {
            "pathOutput": "elements/"
        }
    },
    "jsonToDocs": {
        "doProcess": true,
        "doDropOutputDirectory": true,
        "docTemplates": "json.to.docs.json",
        "json": {
            "pathInput": "elements/"
        },
        "templates": {
            "pathInput": "templates/"
        },
        "docs": {
            "pathOutput": "docs/"
        }
    }
}
```

## baserow.to.json.json

The **baserow.to.json.json** file (set in the attribute `baserowToJSON.databases`) defines what Baserow Tables are exported to JSON. The file must be a valid JSON file consistenting of one object with the property **database** which is an array of **database** objects:

``` json
{
    "databases": 
    [
    ]
}
```

A database object consists of a `database` (the unique number in Baserow), the `apiKey` with read access on Baserow for the Data Tables and an object array of `tables` which hold the tables to export:

``` json
{
    "database": "75",
    "apiKey": "BR_API_KEY",
    "tables": [
        {
            "table": "359",
            "jsonFile": "DAEDALUS/actor.json"
        },
        {
            "table": "367",
            "jsonFile": "DAEDALUS/product.json"
        }
    ]
}
```

An environmental variable needs to be declared either via a .env file stored in root folder or via other means:

```bash
BR_API_KEY={your private API key}
```

If no `apiKey` is declared the default value **BR_API_KEY** is used. Hence, the above example can actually omit the `apiKey` attribute. If you want to use an alternative `apiKey`, simply declare the key you want to use (e.g. **BR_API_KEY_DAEDALUS**) and make sure this key is declared as environmental variable with the correct token as value.

### Optional Database attributes

There are 2 optional attributes you can add to the `database` object:

| Key                      | Type    | Description                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `uniqueTableKey` | string | Include the name if the field that must be unique within the database (e.g. Element-ID). Once include empty values and none-unique values are considered a violation |
| `uniqueTableKeyViolation` | string | Action that happens when a validation is detected for the `uniqueTableKey`. The options are "ALLOW" (export will happen without further action), "WARN" (export will happen but with a warning in the log), "DROP" (export will not happen). The default is "WARN". |

### Optional Table attributes

There are 4 optional attributes you can add to the `table` object:

| Key                      | Type    | Description                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `uniqueTableKeyViolation` | string | Action that happens when a validation is detected for the `uniqueTableKey`. The options are "ALLOW" (export will happen without further action), "WARN" (export will happen but with a warning in the log), "DROP" (export will not happen). This can be used to overwrite for this Table the `database.uniqueTableKeyViolation`. |
| `assetPath`              | string | In case the Baserow Datatable includes a file attribute, the file will be downloaded. This download will be stored in `assets.pathOutput`. The `assetPath` attribute overrides this path. Make sure you include a valid path value such as `myAssets/` or `../myAssets/` relative to `json.pathOutput`. |
| `orderBy`                 | object | Sort the JSON objects based on the attribute value. Sorting occurs after the export from Baserow, but before writing the results to disk.|
| `filterBy`                 | object | Filter the JSON objects based on the attribute value. Filtering occurs after the export from Baserow, but before writing the results to disk.|

#### orderBy

The `orderBy` object is an array which holds one or more attributes that are used to sort the results. The default is to sort in ascending order, but via an optional attribute you can change the sort order to descending.

| Key                      | Type    | Description                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `attribute` | string | Name of the attribute to sort on |
| `direction` | string | Sort direction. Possible values are `asc`, `desc` where `asc` is the default value and can be omitted. |

An example that would first sort on **Element-Name** and then on **Element-ID** is defined as follows:

``` json
{
    "table": "359",
    "jsonFile": "DAEDALUS/actor.json",
    "assetPath": "myAssets/",
    "orderBy": [
        {
            "attribute": "Element-Name"
        },
        {
            "attribute": "Element-ID",
            "direction": "desc"
        }
    ]
}
```

#### filterBy

The `filterBy` object holds an array of `conditionGroups`. The `conditionGroups` array holds one or more `conditions` objects. These `conditions` determine what filtering is applied to the JSON object array.

| Key                      | Type    | Description                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `filterBy.logicalOperator` | string | Determines whether the `conditionGroups` all need to comply (`AND`) or one or more need to comply (`OR`). Possible values are `AND` and `OR` where `AND` is the default value and can be omitted. |
| `conditionGroups` | array | Holds one or more `conditionGroup` objects. The `conditionGroup` determines what filtering logic is applied|
| `conditionGroup.logicalOperator` | string | Determines whether the `conditions` all need to comply (`AND`) or one or more need to comply (`OR`). Possible values are `AND` and `OR` where `AND` is the default value and can be omitted. |
| `conditions` | array | Holds one or more `condition` objects. The `condition` object specifies the filter logic that is applied on an attribute. |
| `condition.attribute` | string | Name of the attribute the filter logic is applied to. |
| `condition.condition` | string | Logic to apply. Possible values are `equals`, `notEquals`, `contains`, `notContains`, `greaterThan`, `lessThan`, `empty` and `notEmpty`. |
| `condition.value` | string, integer or array | Value that is used to apply the `condition` to the `attribute`. |

The following example will only store the JSON objects that have an Element-Name that contains S, U and X:

``` json
{
    "table": "367",
    "jsonFile": "DAEDALUS/product-s-u-x-AND.json",
    "filterBy": {
        "logicalOperator": "AND",
        "conditionGroups": [
            {
                "logicalOperator": "AND",
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "s"
                    }
                ]
            },
            {
                "logicalOperator": "AND",
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "u"
                    }
                ]
            },
            {
                "logicalOperator": "AND",
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "x"
                    }
                ]
            }
        ]
    }
}
```

Since the logicalOperator is `AND` by default the same can be written as:

``` json
{
    "table": "367",
    "jsonFile": "DAEDALUS/product-s-u-x-AND.json",
    "filterBy": {
        "conditionGroups": [
            {
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "s"
                    }
                ]
            },
            {
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "u"
                    }
                ]
            },
            {
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "x"
                    }
                ]
            }
        ]
    }
}
```

When all `conditions` share the same `logicalOperator` all the conditions can be put into one group:

``` json
{
    "table": "367",
    "jsonFile": "DAEDALUS/product-s-u-x-AND.json",
    "filterBy": {
        "conditionGroups": [
            {
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "s"
                    },
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "u"
                    },
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "x"
                    }
                ]
            }
        ]
    }
}
```

If you want to include all elements that have an S, U or X in the Element-Name you add the `logicalOperator` with the value `OR`:

``` json
{
    "table": "367",
    "jsonFile": "DAEDALUS/product-s-u-x-OR.json",
    "filterBy": {
        "conditionGroups": [
            {
                "logicalOperator": "OR",
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "s"
                    },
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "u"
                    },
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "x"
                    }
                ]
            }
        ]
    }
}
```

If you want to include all elements that have an S or U and X in the Element-Name you add the `logicalOperator` with the value `OR`:

``` json
{
    "table": "367",
    "jsonFile": "DAEDALUS/product-s-u-OR-x-AND.json",
    "filterBy": {
        "conditionGroups": [
            {
                "logicalOperator": "OR",
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "s"
                    },
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "u"
                    }
                ]
            },
            {
                "conditions": [
                    {
                        "attribute": "Element-Name",
                        "condition": "contains",
                        "value": "x"
                    }
                ]
            }
        ]
    }
}
```

Similar type of logic can by applied using arrays. This example will only return products that have an Usage that contains both KREATIVE and DAEDALUS:

``` json
{
    "table": "367",
    "jsonFile": "DAEDALUS/product-kreative-daedalus-AND.json",
    "filterBy": {
        "conditionGroups": [
            {
                "conditions": [
                    {
                        "attribute": "Usage",
                        "condition": "equals",
                        "value": [
                            "KREATIVE", "DAEDALUS"
                        ]
                    }
                ]
            }
        ]
    }
}
```

Whereas the following example will include all products that have an Usage of KREATIVE or DAEDALUS or both:

``` json
 {
    "table": "367",
    "jsonFile": "DAEDALUS/product-kreative-daedalus-OR.json",
    "filterBy": {
        "conditionGroups": [
            {
                "logicalOperator": "OR",
                "conditions": [
                    {
                        "attribute": "Usage",
                        "condition": "equals",
                        "value": [
                            "KREATIVE", "DAEDALUS"
                        ]
                    }
                ]
            }
        ]
    }
}
```

Different conditions can be combined. E.g. to create a list of products where the Usage is KREATIVE, but not DAEDALUS:

``` json
{
    "table": "367",
    "jsonFile": "DAEDALUS/product-kreative.json",
    "filterBy": {
        "conditionGroups": [
            {
                "conditions": [
                    {
                        "attribute": "Usage",
                        "condition": "equals",
                        "value": [
                            "KREATIVE"
                        ]
                    },                                    
                    {
                        "attribute": "Usage",
                        "condition": "notEquals",
                        "value": [
                            "DAEDALUS"
                        ]
                    }
                ]
            }
        ]
    }
}
```

## json.to.docs.json

The **json.to.docs.json** file (set in the attribute `jsonToDocs.docTemplates`) defines what Documents are created by converting a JSON Object Arrary by applying one or more Handlebar Templates. The file must be a valid JSON file consistenting of one object with the property **templates** which is an array of **template** objects:

``` json
{
    "templates": 
    [
    ]
}
```

A template object consists of a `json` file reference that holds the JSON Object Array that is used as input, the `templates` to apply for the conversion and the `docsFolder` and `fileName` used for storing the output:

``` json
    {
      "json": "DAEDALUS/actor.json",
      "templates": [
        "generic-intro.md",
        "actor-items-table-01.md",
        "generic-outro.md"
      ],
      "docsFolder": "actor/all-in-one",
      "fileName": "actor_all.md"
    }
```

The input files (`json` and `templates`) and output folder (`docsFolder`) are relative to the folders declared in `process.json`. The full paths will be `{jsonToDocs.json.pathInput}/{json}`, `{jsonToDocs.templates.pathInput}/{templates}` and `{jsonToDocs.docs.pathOutput}/{docsFolders}/{fileName}`. 

The `docsFolder` is an optional attribute. If ommitted the results will be stored in `{jsonToDocs.docs.pathOutput}/{fileName}`.

The `templates` need to be valid [Handlebars](https://handlebarsjs.com/) templates. Templates are applied in the order listed and the results are combined as one file.

### Additional Handlebars Helpers

All features of the [Handlebars templating language](https://handlebarsjs.com/guide/) are available. In addition to that additional Helpers are created to support with specific cases.

| Helper             | Purpose    | Example                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `parsedotnotation {fieldName}` | An attribute name in the JSON object can contain a `.`. This breaks Handlebars. If you want to use an attribute with a `.` in the name use this Handler as escape. | `<ul>{{#each (parsedotnotation "Producten.Element-Name")}}<li>{{this}}</li>{{/each}}</ul>` |
| `isequal {value1} {value2}` | Returns `true` when the two value are equals. Values can refer to a fieldName or a static value. | `{{#if (isequal Element-Type-Full "Actor: Person")}}Person{{else}}Not a Person{{/if}}` |
| `#isDefined {fieldName}` | Returns true when the fieldName is present in the object. | `{{#isDefined Product}}"Product": {{Product}}{{/isDefined}}`|
| `localizeAsset {fieldName}` | Copies the file to the `assets.pathOutput` folder and returns the relative path to the asset from the folder `docs.pathOutput`. | `{{#each File}}<img src="{{localizeAsset name}}" alt="{{visible_name}}"" width="100">{{/each}}`|
| `replaceNewlines {fieldName} tag="{replacementCharacter}"` | Replaces newline characters with the `{replacementCharacter}`. If no tag is provided the replacement character is ' '. Not that when HTML is used you need to use `{{{...}}}`.| `"Description": "{{replaceNewlines Description}}"` of `"Description": "{{{replaceNewlines Description tag="<BR>"}}}"`|
| `groupby` & `eachGroup`| Allows you to dynamically group data by multiple levels using dot-separated keys (e.g., "Organization.Scope") | __see below__|

#### Examples: groupBy and eachGroup

**1-level grouping**
``` handlebars
{{#groupBy items "Organization"}}
## {{group}}
  {{#each items}}
  - **{{Name}}** ({{Mail-Address}})
  {{/each}}
{{/groupBy}}
```

**2-level grouping**
``` handlebars
{{#groupBy items "Organization.Scope"}}
## {{group}}
  {{#eachGroup subgroups}}
  ### {{group}}

    {{#each items}}
    - **{{Name}}** ({{Mail-Address}})
    {{/each}}

  {{/eachGroup}}
{{/groupBy}}
```

**3-level grouping**
``` handlebars
{{#groupBy items "Active.Organization.Scope"}}
## {{group}}
  {{#eachGroup subgroups}}
  ### {{group}}

    {{#eachGroup subgroups}}
    #### {{group}}

      {{#each items}}
      - **{{Name}}** ({{Mail-Address}})
      {{/each}}

    {{/eachGroup}}

  {{/eachGroup}}
{{/groupBy}}
```

### Dynamic file names

The `fileName` can include dynamic values. The dynamic value must be an attribute that is available in the JSON Object Array that is applied to the template. You refer to the `fieldName` using similar syntax as used in Handlebars: `{{fieldName}}`. If the fieldName is not found it is replaced with the value `unknown`.

### Optional attributes

There are 3 optional attributes you can add to the `template` object:

| Key                      | Type    | Description                                                                                     |
|--------------------------|---------|-------------------------------------------------------------------------------------------------|
| `generateSeparateFiles` | boolean | The default is `false` and will store all results in one file. If you want one file per JSON Object set this attribute to `true` |
| `fileType`| string | The default is `doc` and will store the output without parsing the results. If you want to store `json` files add this so that the file is converted to proper JSON before storing.|
| `extraAttributes` | object | If you want to add additional meta data, not present in the JSON Object, you can add a list of key-value pairs as extraAttributes to make these available to the template. |
| `orderBy`                 | object | Sort the JSON objects based on the attribute value. |
| `filterBy`                 | object | Filter the JSON objects based on the attribute value. |

The `orderBy` and `filterBy` implement 100% the same logic as explained in the **baserow.to.json.json** section. An explanation will therefore not be repeated.

### Examples

All JSON Objects in the `DAEDALUS/actor.json` file are converted using 3 templates as one file. The file has a dynamic value `{{title}}` which is set via an extraAttribute.

``` json
{
    "json": "DAEDALUS/actor.json",
    "templates": [
        "generic-intro.md",
        "actor-items-table-01.md",
        "generic-outro.md"
    ],
    "docsFolder": "actor/all-in-one",
    "fileName": "{{title}}_all.md",
    "extraAttributes": {
        "title": "Actor",
        "subTitle": "Users, Systems & SBBs"
    }
}
```

 These attributes are now also available for the templates e.g. for setting the title in a markdown file:

``` markdown
# {{#if title}}{{title}}{{else}}_title not specified_{{/if}}

{{#if subTitle}}**{{subTitle}}**{{/if}}
```

The following example demonstrates the usage of `orderBy` and `filterBy`. Only those Actors with a Element-Name that contains the letter `A` are included and the results are sorted by Element-Name in ascending order.

``` json
{
    "json": "DAEDALUS/actor.json",
    "templates": [
        "generic-intro.md",
        "actor-items-table-01.md",
        "generic-outro.md"
    ],
    "docsFolder": "actor/all-in-one",
    "fileName": "actor_only_a.md",
    "extraAttributes": {
        "title": "Actor (containing an A in Element-Name)",
        "subTitle": "Users, Systems & SBBs"
    },
    "orderBy": [
    {
        "attribute": "Element-Name"
    }
    ],
    "filterBy": {
        "conditionGroups": [
            {
            "conditions": [
                {
                "attribute": "Element-Name",
                "condition": "contains",
                "value": "A"
                }
            ]
            }
        ]
    }
}
```

The following example will create one file for each Actor that is in the JSON Object array. The file name uses the `Element-ID` as dynamic value in the fileName.

``` json
{
    "json": "DAEDALUS/actor.json",
    "templates": [
       "actor-single-01.md"
    ],
    "docsFolder": "actor/all-single",
    "fileName": "actor_{{Element-ID}}.md",
    "generateSeparateFiles": true
}
```
